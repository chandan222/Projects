<?php 
	session_start();
	$con =mysqli_connect("localhost","root","","rtc");
	if(!$con){
		die("connection error");
	}
	
	$email = $password ="";

		if ($_SERVER["REQUEST_METHOD"] == "POST") {
 			 $password = $_POST["password"];
  			$email = $_POST["email"];
  
		}
		$sql="select * from login where email='$email' and password='$password' ";
		$result=mysqli_query($con,$sql);
		if($row=mysqli_fetch_array($result,MYSQLI_NUM)){
			$field=$row[2];
			$_SESSION['username']=$email;
			$_SESSION['password']=$password;
			
		}
		else{
			echo "not found";
		}
		
		if($field=='college'){
			header('Location: upload.php');
		}
		
		if($field=='admin'){
			header('Location: admin.php');
		}
		if($field=='rtc'){
			header('Location: rtc.php');
		}

	?>