<?php
$fname = $mname= $name= $anumber = $gender = $dob= $college="";

$file=$_FILES["csv_file"]["tmp_name"];
$handle = fopen($file, "r");
$first= $second = $third ="";
$con=mysqli_connect("localhost","root","","rtc");
if(!$con){
die("connection failed");
}
    while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
        {
          $name = $filesop[0];
		   $fname= $filesop[1];
			 $mname =$filesop[2];
			 $anumber=$filesop[3];
			 $gender=$filesop[4];
			 $dob=$filesop[5];
			 $college=$filesop[6];
			 
			 $sql="insert into college_db values('$name','$fname' ,'$mname' , '$anumber' ,'$gender','$dob' ,'$college')";
			 if(!mysqli_query($con,$sql)){
			 	echo "failed";
				}
		  }
$target_dir = "uploads/data/";
$target_file = $target_dir . basename($_FILES["csv_file"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.<br>";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["csv_file"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if( $imageFileType != "csv" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["csv_file"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["csv_file"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
?>