<?php

	$number= $field = "";
	if($_SERVER["REQUEST_METHOD"]=="POST"){
		$number=$_POST["aadhar"];
		$field=$_POST["identity"];
	}
		$con=mysqli_connect("localhost","root","","rtc");
	if(!$con){
		die("connection problem");
	}
	if($filed="student"){
		$sql="delete from above_education where aadhar_number='$number'";
		if(!mysqli_query($con,$sql)){
			exit("unable to remove education details");
		}
		
		$sql="delete from above_pass where aadhar_number='$number'";
		if(!mysqli_query($con,$sql)){
			exit("unable to remove pass details");
		}
		
				$sql="delete from above_resident where aadhar_number='$number'";
		if(!mysqli_query($con,$sql)){
			exit("unable to remove resident details");
		}
		
				$sql="delete from above_personal where aadhar_number='$number'";
		if(!mysqli_query($con,$sql)){
			exit("unable to remove personal details");
		}
	}if($filed="non-student"){
		$sql="delete from non_student_pass where anumber='$number'";
		if(!mysqli_query($con,$sql)){
			exit("unable to remove pass details");
		}
		
				$sql="delete from non_student_resident where anumber='$number'";
		if(!mysqli_query($con,$sql)){
			exit("unable to remove resident details");
		}
		
				$sql="delete from non_student_personal where anumber='$number'";
		if(!mysqli_query($con,$sql)){
			exit("unable to remove personal details");
		}
		
	}
		header("Location: admin.php");
?>