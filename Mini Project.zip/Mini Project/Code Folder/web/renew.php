<?php
$name=$number=$dob=$proff="";
if($_SERVER["REQUEST_METHOD"]=="POST"){
	$name=$_POST["name"];
	$number=$_POST["number"];
	$dob=$_POST["dob"];
	$proff=$_POST["proff"];
}
$con=mysqli_connect("localhost","root","","rtc");
	if(!$con){
		die("connection problem");
	}
	
	if($proff=="Student"){
		$sql="select * from above_pass where aadhar_number='$number'";
	$result=mysqli_query($con,$sql);
		//$row=mysqli_fetch_row($result);
	//	echo "$row[4]";
	//	$sql="update above_pass set duration='3' where";
	if($result>0){
			header("Location:renewresult.php");
	}
	
	}
	
	if($proff=="Non-Student"){
				$sql="select * from non_student_pass where aadhar_number='$number'";
	$result=mysqli_query($con,$sql);
		//$row=mysqli_fetch_row($result);
	//	echo "$row[4]";
	//	$sql="update above_pass set duration='3' where";
	if($result>0){
			header("Location:renewresult.php");
	}
	
	}
	}
	
?>