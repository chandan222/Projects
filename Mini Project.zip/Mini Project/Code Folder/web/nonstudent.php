<?php
		$name = $fname = $dob= $gender =$mnumber=$anumber = $email =$employee = "";
	
	$village=$mandal=$district=$pin_number= $address="";
	$type_of_pass = $route_to=$route_from=$collect=$duration="";
	if($_SERVER["REQUEST_METHOD"]=="POST"){
		$name =$_POST["name"];
		$fname=$_POST["fname"];
	
		$dob=$_POST["dob"];
		$gender =$_POST["gender"];
		$mnumber=$_POST["mnumber"];
		$anumber = $_POST["aadhar"];
		$email =$_POST["email"];
		$employee=$_POST["employee"];
		
		
		$village=$_POST["village"];
		$mandal=$_POST["rmandal"];
		$district=$_POST["rdistrict"];
		$address==$_POST["address"];
		$pin_number= $_POST["pincode"];
		
		$type_of_pass = $_POST["passtype"];
		$route_from=$_POST["from"];
		$route_to=$_POST["to"];
		$collect=$_POST["collect"];
		$duration=$_POST["duration"];
	}
		$con=mysqli_connect("localhost","root","","rtc");
	if(!$con){
		die("connection problem");
	}
	$folder="uploads/photo/non-student/";

        
            $uploa=$_FILES["myimage"]["name"];
            move_uploaded_file($_FILES["myimage"]["tmp_name"], "$folder".$_FILES["myimage"]["name"]);
            
	
	
	
	$sql="insert into non_student_personal values('$name', '$fname','$dob','$gender', '$mnumber','$anumber', '$email','$employee','$uploa','$folder')";
	if(!mysqli_query($con,$sql)){
		exit( "error while uploading data in personal ");
	}
	$sql="insert into non_student_pass values('$type_of_pass','$route_from','$route_to','$duration','$collect','$anumber' )";
	if(!mysqli_query($con,$sql)){
		exit("error while uploading data in pass ");
	}
	$sql="insert into non_student_resident values('$village','$mandal','$district','$address','$pin_number' ,'$anumber')";
	if(!mysqli_query($con,$sql)){
		exit("error while uploading data in resident");
	}
		 include('way2sms-api.php');
   sendWay2SMS ( '8121821991' , 'H3866T' , '$mnumber' , 'Thanks for registering on RTC.please show your aadhar card while collectng the pass on the counter'); 
   header("Location:done.php");
?>