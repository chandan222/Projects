<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>TSRTC</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="TSRTC, Bus transport, RTC, Telangan Bus Transport " />
<script type="application/x-javascript"> 
addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="https://www.w3schools.com/lib/w3.css" rel="stylesheet" type="text/css" />
<link href="css/style.css" rel='stylesheet' type='text/css' />
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
<!--start-smoth-scrolling-->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
				});
			});
		</script>
<!--start-smoth-scrolling-->
</head>
<body>
	<!--head-->
	<?php 
		session_start();
		if(!isset($_SESSION['username'])){
			header("Location:login.php");
			
		}
	
	?>
	<div class="head" id="home">
		<div class="container">
			<div class="head-top">
				<div class="col-md-6 h-left">
					<p>Contact No:040 30102829 </p>
				</div>
				<div class="col-md-6 h-right">
					<p><a href="logout.php">Logout</a> </p>
				</div>
				<!--<div class="col-md-6 h-right">
					<ul>
						<li><a href="#"><span class="fb"> </span></a></li>
						<li><a href="#"><span class="twit"> </span></a></li>
						<li><a href="#"><span class="pin"> </span></a></li>
						<li><a href="#"><span class="rss"> </span></a></li>
					</ul>
				</div>-->
				<div class="clearfix"></div>
			</div>	
		</div>
	</div>
	<!--head-->
	<!--header-->	
	<div class="header">
		<div class="container">
			<div class="header-main">
				<div class="logo">
					<a href="index.html"><h1>TSRTC</h1></a>
				</div>
				<div class="pages-top heading"><br>
				<h2>Admin</h2><br>
			</div>
	</div>	
	</div>	
<div>
<form method="post" action="delete.php" enctype="multipart/form-data"  >
<center>

<label>Enter the Aadhar number</label>
<input type="text" name="aadhar"><br>
  <input type="radio" name="identity" value="male" />Student <input type="radio" name="identity" value="Non-Student" />Non-Student <br>
<input type="submit" value="delete">
</center>
</form>
</div>

	</div>
	<!--//header-->
	<!--typo-starts-->
	<div class="pages">
		<div class="container">
				<!--address-end-->
	<!--footer-starts-->
	<br>
	<br>
	
	<div class="footer">
		<div class="container">
			<div class="footer-top">
				<a href="index.html"><h3>TSRTC</h3></a>
				<p>© 2017 TSRTC. All Rights Reserved | Design by  <a href="http://w3layouts.com/" target="_blank">GOV</a> </p>
				<a href="#home" class="scroll"><img src="images/top-arrow.png" alt="" /></a>
			</div>
		</div>
	</div>
	<!--footer-end-->
	
</body>
</html>