<?php
	$name = $fname=$mname = $dob= $gender =$mnumber=$anumber = $email =$handi = "";
	$college_name= $current_year =$college_location = $type_of_college=$current_course=$student_admission_number=$college_district=$college_mandal=$college_pin="";
	$house_number=$street=$village=$mandal=$district=$pin_number= "";
	$type_of_pass = $route_to=$route_from=$collect=$duration="";
	if($_SERVER["REQUEST_METHOD"]=="POST"){
		$name =$_POST["name"];
		$fname=$_POST["fathername"];
		$mname =$_POST["mname"];
		$dob=$_POST["dob"];
		$gender =$_POST["gender"];
		$mnumber=$_POST["mnumber"];
		$anumber = $_POST["anumber"];
		$email =$_POST["email"];
		$college_name= $_POST["cname"];
		$current_year =$_POST["cyear"];
		$college_location =$_POST["clocation"];
		$type_of_college=$_POST["toc"];
		$current_course=$_POST["course"];
		$student_admission_number=$_POST["adnumber"];
		$college_district=$_POST["cdistrict"];
		$college_mandal=$_POST["cmandal"];
		$college_pin=$_POST["pincode"];
		$house_number=$_POST["hnumber"];
		$street=$_POST["street"];
		$village=$_POST["village"];
		$mandal=$_POST["rmandal"];
		$district=$_POST["rdistrict"];
		$pin_number= $_POST["rpincode"];
		$type_of_pass = $_POST["passtype"];
		$route_from=$_POST["routefrom"];
		$route_to=$_POST["routeto"];
		$collect=$_POST["collect"];
		$duration=$_POST["duration"];
	}
	$con=mysqli_connect("localhost","root","","rtc");
	if(!$con){
		die("connection problem");
	}
	$sql= "select * from college_db where student_name='$name' and aadhar_number='$anumber' and college='$college_name'";
	$result=mysqli_query($con,$sql);
	if(mysqli_num_rows($result) > 0){
		$folder="uploads/photo/student/";

        
            $uploa=$_FILES["myimage"]["name"];
            move_uploaded_file($_FILES["myimage"]["tmp_name"], "$folder".$_FILES["myimage"]["name"]);
            
	$sql="insert into above_personal values('$name', '$fname','$mname','$anumber', '$gender','$dob', '$mnumber', '$email','$uploa','$folder')";
	if(!mysqli_query($con,$sql)){
		exit( "error while uploading data in personal ");
	}
	$sql="insert into above_education values('$college_name', '$current_year' ,'$college_location' , '$type_of_college','$current_course','$student_admission_number','$college_district','$college_mandal','$college_pin','$anumber')";
	if(!mysqli_query($con,$sql)){
		exit("error while uploading data in educational ");
	}

	$d=3;
	echo date('d/m/y',strtotime('+'.$d.'2months'));
	$sql="insert into above_pass values('$type_of_pass','$route_from','$route_to','$duration ','$collect' ,'$anumber')";
	if(!mysqli_query($con,$sql)){
		exit("error while uploading data in pass ");
	}
	$sql="insert into above_resident values('$house_number','$street','$village','$mandal','$district','$pin_number','$anumber' )";
	if(!mysqli_query($con,$sql)){
		exit("error while uploading data in resident");
	}
	 include('way2sms-api.php');
   sendWay2SMS ( '8121821991' , 'H3866T' , '$mnumber' , 'Dear user registration successful confirmation number is'); 
   header("Location:done.php");
	}else{
		
		exit("Match not found");
	}
	
	
?>